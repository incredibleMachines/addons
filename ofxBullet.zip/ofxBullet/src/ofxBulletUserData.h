/*
 *  ofxBulletUserData.h
 *  ofxBullet_v3
 *
 *  Created by Nick Hardeman on 5/26/11.
 *  Copyright 2011 Arnold Worldwide. All rights reserved.
 *
 */

#pragma once

// extend this class if you wish to pass in custom data for the user data on the rigid body //
class ofxBulletUserData {
public:
	ofxBulletUserData() { }
	~ofxBulletUserData() { }
};